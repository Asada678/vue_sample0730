<template>
  <div class="other">
    This is other2 page.
  </div>
</template>

<script>
export default {

}
</script>

<style scoped>
.other {
  padding: 200px;
}
</style>