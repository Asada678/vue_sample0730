<template>
  <div class="">
    This is home page.
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>